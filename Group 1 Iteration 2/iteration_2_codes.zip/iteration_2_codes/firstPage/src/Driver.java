
public class Driver {
    public static void main(String[] args){
        myApp app=new myApp();
    }
}
